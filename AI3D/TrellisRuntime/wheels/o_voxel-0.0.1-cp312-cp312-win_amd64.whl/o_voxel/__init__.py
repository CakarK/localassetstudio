# Local Asset Studio modification: lazy imports; no restricted rasterizer.
import importlib

def __getattr__(name):
    if name not in {"convert", "io", "postprocess", "rasterize", "serialize"}:
        raise AttributeError(name)
    module = importlib.import_module("." + name, __name__)
    globals()[name] = module
    return module
